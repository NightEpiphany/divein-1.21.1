package com.moigferdsrte.divein;

import com.moigferdsrte.divein.network.CustomPacket;
import com.mojang.logging.LogUtils;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(Divein.MODID)
public class Divein {

    public static final String MODID = "divein";

    public static final Logger LOGGER = LogUtils.getLogger();

    public Divein() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        modEventBus.addListener(this::commonSetup);

        // Register ourselves for server and other game events we are interested in
        MinecraftForge.EVENT_BUS.register(this);

        // Register our mod's ForgeConfigSpec so that Forge can create and load the config file for us
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {

        CustomPacket.register();


        CustomPacket.INSTANCE.registerMessage(
                CustomPacket.id++,
                CustomPacket.class,
                CustomPacket::encode,
                CustomPacket::decode,
                CustomPacket::handleOnClient
        );
    }

    public static boolean checkWaterBelow(Player player, int blocks) {
        if (player.isInWater()) return true;
        for (int i = 1; i <= blocks; i++) {
            if (player.level().getBlockState(player.blockPosition().below(i)).is(Blocks.WATER) &&
                    (player.level().getBlockState(player.blockPosition().below(i - 1)).is(Blocks.AIR) || player.level().getBlockState(player.blockPosition().below(i - 1)).is(Blocks.CAVE_AIR))
            ) {
                if (!player.level().getBlockState(player.blockPosition().below(i + 1)).is(Blocks.WATER)) return false;
                for (int j = 1; j <= Config.triggerDepth; j++) {
                    if (player.level().getBlockState(player.blockPosition().below(i - 1 + j)).getFluidState().getType() != Fluids.WATER) return false;
                }
                return true;
            }
            if (!(player.level().getBlockState(player.blockPosition().below(i)).is(Blocks.AIR) || player.level().getBlockState(player.blockPosition().below(i)).is(Blocks.CAVE_AIR))) break;
        }
        return false;
    }

    public static boolean checkLavaBelow(Player player, int blocks) {
        if (player.isInLava()) return true;
        for (int i = 1; i <= blocks; i++) {
            if (player.level().getBlockState(player.blockPosition().below(i)).getFluidState().getType() == Fluids.LAVA &&
                    (player.level().getBlockState(player.blockPosition().below(i - 1)).is(Blocks.AIR) || player.level().getBlockState(player.blockPosition().below(i - 1)).is(Blocks.CAVE_AIR))) {
                for (int j = 1; j <= Config.triggerDepth; j++) {
                    if (player.level().getBlockState(player.blockPosition().below(i - 1 + j)).getFluidState().getType() != Fluids.LAVA) return false;
                }
                return true;
            }
            if (!(player.level().getBlockState(player.blockPosition().below(i)).is(Blocks.AIR) || player.level().getBlockState(player.blockPosition().below(i)).is(Blocks.CAVE_AIR))) break;
        }
        return false;
    }

    // You can use EventBusSubscriber to automatically register all static methods in the class annotated with @SubscribeEvent
    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {

        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {

        }
    }
}
