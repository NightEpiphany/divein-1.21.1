package com.moigferdsrte.divein.mixin;

import com.moigferdsrte.divein.Config;
import com.moigferdsrte.divein.extension.AnimationEffect;
import com.moigferdsrte.divein.network.CustomPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

import static com.moigferdsrte.divein.Divein.checkLavaBelow;
import static com.moigferdsrte.divein.Divein.checkWaterBelow;

@OnlyIn(Dist.CLIENT)
@Mixin(value = Minecraft.class, priority = 500)
public class ClientPacketSenderMixin {
    @Shadow
    @Nullable
    public LocalPlayer player;

    @Shadow
    @Nullable
    public ClientLevel level;
    @Unique
    private boolean divein_1_20_1_forge$waterDrop;
    @Unique
    private boolean divein_1_20_1_forge$lavaDrop;

    @Inject(method = "tick", at = @At("RETURN"))
    private void tick(CallbackInfo ci) {
        if (player == null) return;
        divein_1_20_1_forge$waterDrop = checkWaterBelow(player, Config.fluidLevelDetectHeight);
        divein_1_20_1_forge$lavaDrop = checkLavaBelow(player, Config.fluidLevelDetectHeight * 2);
        if (divein_1_20_1_forge$waterDrop || divein_1_20_1_forge$lavaDrop) {
            if (player.getDeltaMovement().y < 0)
                divein_1_20_1_forge$tryPlayAnimationOnServerside();
        }
    }

    @Unique
    private void divein_1_20_1_forge$tryPlayAnimationOnServerside() {
        var client = (Minecraft) ((Object)this);
        if (player == null || client.isPaused()) {
            return;
        }
        boolean hasRes = player.hasEffect(MobEffects.FIRE_RESISTANCE);
        float sensitivity = (float) Config.triggerSensitivity;
        if (sensitivity < 0) sensitivity = 0;
        if (sensitivity > 1) sensitivity = 1;
        boolean isFalling = player.getDeltaMovement().y < sensitivity - 1.0f
                && !player.onGround()
                && (Objects.requireNonNull(client.level).getBlockState(player.blockPosition().below()).is(Blocks.AIR) || Objects.requireNonNull(client.level).getBlockState(player.blockPosition().below()).is(Blocks.CAVE_AIR))
                && !player.getAbilities().flying;
        if (isFalling) {
            if (divein_1_20_1_forge$waterDrop || hasRes) {
                var visuals = new AnimationEffect.Visuals("dive", AnimationEffect.Particles.DIVE);
                //ServerNetwork.networkC2S_Send(new Packets.AnimationPublish(player.getId(), visuals, player.getDeltaMovement()));
//                FriendlyByteBuf passedData = new FriendlyByteBuf(Unpooled.buffer());
//                passedData.writeInt(player.getId());
//                passedData.writeUtf("dive");
//                passedData.writeVector3f(player.getDeltaMovement().toVector3f());
//                ClientSidePacketRegistry.INSTANCE.sendToServer(Divein.ANIMATION_C2S, passedData);
                CustomPacket.sendToServer(
                        player.getId(),
                        "dive",
                        player.getDeltaMovement().toVector3f()
                );
                AnimationEffect.playVisuals(visuals, player, player.getDeltaMovement());
            }
            if (divein_1_20_1_forge$lavaDrop) {
                var visuals = new AnimationEffect.Visuals("lava_dive", AnimationEffect.Particles.DIVE);
                //ServerNetwork.networkC2S_Send(new Packets.AnimationPublish(player.getId(), visuals, player.getDeltaMovement()));
//                FriendlyByteBuf passedData = new FriendlyByteBuf(Unpooled.buffer());
//                passedData.writeInt(player.getId());
//                passedData.writeUtf("lava_dive");
//                passedData.writeVector3f(player.getDeltaMovement().toVector3f());
//                ClientSidePacketRegistry.INSTANCE.sendToServer(Divein.ANIMATION_C2S, passedData);
                CustomPacket.sendToServer(
                        player.getId(),
                        "lava_dive",
                        player.getDeltaMovement().toVector3f()
                );
                AnimationEffect.playVisuals(visuals, player, player.getDeltaMovement());
            }
        }
    }
}