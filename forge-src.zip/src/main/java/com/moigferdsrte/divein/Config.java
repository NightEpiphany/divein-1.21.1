package com.moigferdsrte.divein;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;

// An example config class. This is not required, but it's a good idea to have one to keep your config organized.
// Demonstrates how to use Forge's config APIs
@Mod.EventBusSubscriber(modid = Divein.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class Config {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.DoubleValue TRIGGER_SENSITIVITY = BUILDER
            .comment("Animation Trigger Sensitivity")
            .defineInRange("triggerSensitivity", 0.615d, 0.0d, 1.0d);


    public static final ForgeConfigSpec.IntValue DETECT_HEIGHT = BUILDER
            .comment("Fluid Level Detect Height")
            .defineInRange("fluidLevelDetectHeight", 28, 0, Integer.MAX_VALUE);


    public static final ForgeConfigSpec.IntValue MINIMUM_DEPTH = BUILDER
            .comment("Minimum Animation Trigger Depth")
            .defineInRange("triggerDepth", 2, 1, Integer.MAX_VALUE);


    public static final ForgeConfigSpec.DoubleValue SPEED = BUILDER
            .comment("Minimum Animation Trigger Depth")
            .defineInRange("speedModifier", 0.92323d, 0, 10.0d);


    static final ForgeConfigSpec SPEC = BUILDER.build();


    public static int fluidLevelDetectHeight;


    public static double triggerSensitivity;


    public static int triggerDepth;


    public static double speedModifier;



    @SubscribeEvent
    static void onLoad(final ModConfigEvent event) {
        if (event.getConfig().getSpec() == SPEC) {
            fluidLevelDetectHeight = DETECT_HEIGHT.get();
            triggerSensitivity = TRIGGER_SENSITIVITY.get();
            triggerDepth = MINIMUM_DEPTH.get();
            speedModifier = SPEED.get();
        }
    }
}
