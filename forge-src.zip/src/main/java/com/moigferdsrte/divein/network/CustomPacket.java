package com.moigferdsrte.divein.network;

import com.moigferdsrte.divein.extension.AnimationEffect;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import org.joml.Vector3f;

import java.util.function.Supplier;

import static com.moigferdsrte.divein.Divein.MODID;

public record CustomPacket(int playerId, String animationName, Vector3f vec) {
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MODID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    public static int id = 0;

    public static void register() {

        INSTANCE.registerMessage(id++, CustomPacket.class,
                CustomPacket::encode,
                CustomPacket::decode,
                CustomPacket::handleOnServer);
    }


    private static void handleOnServer(CustomPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sender = ctx.get().getSender();
            if (sender != null) {
                ServerLevel level = (ServerLevel) sender.level();


                level.getPlayers(player -> player.getId() != sender.getId())
                        .forEach(player -> {

                            INSTANCE.send(PacketDistributor.PLAYER.with(() -> player),
                                    new CustomPacket(packet.playerId, packet.animationName, packet.vec));
                        });
            }
        });
        ctx.get().setPacketHandled(true);
    }

    public static void handleOnClient(CustomPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> handleClientPacket(packet, ctx))
        );
        ctx.get().setPacketHandled(true);
    }

    private static void handleClientPacket(CustomPacket packet, Supplier<NetworkEvent.Context> ctx) {
        var client = Minecraft.getInstance();
        if (client.level != null) {
            var entity = client.level.getEntity(packet.playerId);
            if (entity instanceof Player player) {
                AnimationEffect.playVisuals(
                        new AnimationEffect.Visuals(packet.animationName, AnimationEffect.Particles.DIVE),
                        player,
                        new Vec3(packet.vec.x, packet.vec.y, packet.vec.z)
                );
            }
        }
    }

    public static CustomPacket decode(FriendlyByteBuf passedData) {
        return new CustomPacket(passedData.readInt(), passedData.readUtf(), passedData.readVector3f());
    }

    public void encode(FriendlyByteBuf passedData) {
        passedData.writeInt(playerId);
        passedData.writeUtf(animationName);
        passedData.writeVector3f(vec);
    }


    public static void sendToServer(int playerId, String animationName, Vector3f vec) {
        INSTANCE.sendToServer(new CustomPacket(playerId, animationName, vec));
    }
}
